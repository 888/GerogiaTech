import socketserver
import sys
from spam_scorer import SpamScorer
PORT = int(sys.argv[1])
spamScorer = SpamScorer(sys.argv[2])

class UDPServer(socketserver.BaseRequestHandler):
    def handle(self):
        self.data = self.request[0].strip()
        print("Recieving Data from %s\n"%self.client_address[0])
        print("Recieved: ", self.data)
        numSusWords, score, susWords = spamScorer.spamScore(self.data.decode("utf-8"))
        res = "%s %s %s\n" % (numSusWords, score, " ".join(susWords))
        print("Responding: ", res)
        socket = self.request[1]
        socket.sendto(bytes(res,'utf-8'),self.client_address )
        print("---------------------------")


HOST = "127.0.0.1"
print("server running at 127.0.0.1:",PORT)
print("Ctrl+c to close server")
server = socketserver.UDPServer((HOST, PORT), UDPServer)
server.serve_forever()

