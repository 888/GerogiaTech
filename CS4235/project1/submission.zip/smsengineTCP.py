import socketserver
import sys
from spam_scorer import SpamScorer
PORT = int(sys.argv[1])
spamScorer = SpamScorer(sys.argv[2])

class TCPServer(socketserver.StreamRequestHandler):
    def handle(self):
        print("Connection Established\n")
        self.data = self.rfile.readline().strip()
        print("Recieved: ",self.data,"\n")
        numSusWords, score, susWords = spamScorer.spamScore(self.data.decode("utf-8"))
        res = "%s %s %s\n" % (numSusWords, score, " ".join(susWords))
        print("Responding: ", res)
        self.wfile.write(bytes(res,'utf-8'))

    def finish(self):
        print('Connection Closed\n-----------------------------------')

HOST = "127.0.0.1"
print("server running at 127.0.0.1:",PORT)
print("Ctrl+c to close server")
server = socketserver.TCPServer((HOST, PORT), TCPServer)
server.serve_forever()

